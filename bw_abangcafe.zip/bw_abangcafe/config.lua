print("^2BW^7-^2AbangCafe ^7v^41^7.^40^7.^40^5hotfix ^7- ^2AbangCafe Script by ^1BearWhite^7")

return {
    CookDuration = 10000,
    BlipCoords = vec3(-1791.51, 2176.04, 120.89),

    Zones = {
        { coords = vec3(-1784.94, 2154.59, 120.89), radius = 0.5, icon = 'far fa-clipboard', event = 'bw_abangcafe:client:frontTray', label = 'Food Tray', type = 'stash', stashLabel = 'AC_Front_Tray_1', slots = 10, weight = 75000}, 
        { coords = vec3(-1788.70, 2153.51, 120.89), radius = 0.9, icon = 'fa-solid fa-beer-mug-empty', event = 'bw_abangcafe:client:drinkStation', label = 'Make Drinks', job = 'abangcafe' }, 
        { coords = vec3(-1785.95, 2151.36, 120.89), radius = 0.9, icon = 'fa-solid fa-burger', event = 'bw_abangcafe:client:cookBurgers', label = 'Make Burgers', job = 'abangcafe' }, 
        ---{ coords = vec3(-1784.18, 2151.40, 120.89), radius = 0.7, icon = 'fa-solid fa-fire-burner', event = 'bw_abangcafe:client:friesStation', label = 'Make Fries', job = 'abangcafe' },
        { coords = vec3(-1793.40, 2150.88, 120.89), radius = 0.7, icon = 'fa-solid fa-box-open', event = 'bw_abangcafe:client:ingredientStore', label = 'Ingredients', job = 'abangcafe', type = 'shop' },
        { coords = vec3(-1787.76, 2151.39, 120.89), radius = 0.7, icon = 'far fa-clipboard', event = 'bw_abangcafe:client:passThrough', label = 'Big Tray', job = 'abangcafe', type = 'stash', stashLabel = 'AC_Big_Tray', slots = 20, weight = 150000 },
        { coords = vec3(-1787.91, 2154.69, 120.89), radius = 0.5, icon = 'far fa-clipboard', event = 'bw_abangcafe:client:frontTray2', label = 'Food Tray', type = 'stash', stashLabel = 'AC_Front_Tray_2', slots = 10, weight = 75000},
    },
    Items = { -- qb-inventory, ew
    label = 'Shop',
        slots = 21,
        items = {
			[1] = { name = "ayam", price = 500, amount = 50, info = {}, type = "item", slot = 1, },
			[2] = { name = "mixvege", price = 500, amount = 50, info = {}, type = "item", slot = 2, },
			[3] = { name = "coslow", price = 500, amount = 50, info = {}, type = "item", slot = 3, },
			[4] = { name = "water_bottle", price = 500, amount = 50, info = {}, type = "item", slot = 4, },
			[5] = { name = "mee", price = 500, amount = 50, info = {}, type = "item", slot = 5, },
			[6] = { name = "minyak", price = 500, amount = 50, info = {}, type = "item", slot = 6, },
			[7] = { name = "pingan", price = 500, amount = 50, info = {}, type = "item", slot = 7, },
			[8] = { name = "tepung", price = 500, amount = 50, info = {}, type = "item", slot = 8, },
			[9] = { name = "planta", price = 500, amount = 50, info = {}, type = "item", slot = 9, },
			[10] = { name = "telur", price = 500, amount = 50, info = {}, type = "item", slot = 10, },
			[11] = { name = "kari", price = 500, amount = 50, info = {}, type = "item", slot = 11, },
			[12] = { name = "teh", price = 500, amount = 50, info = {}, type = "item", slot = 12, },
			[13] = { name = "daunpisang", price = 500, amount = 50, info = {}, type = "item", slot = 13, },
			[14] = { name = "milo", price = 500, amount = 50, info = {}, type = "item", slot = 14, },
			[15] = { name = "apple", price = 500, amount = 50, info = {}, type = "item", slot = 15, },
			[16] = { name = "strawberry", price = 500, amount = 50, info = {}, type = "item", slot = 16, },
			[17] = { name = "cawan", price = 500, amount = 50, info = {}, type = "item", slot = 17, },
			[18] = { name = "mangkuk", price = 500, amount = 50, info = {}, type = "item", slot = 18, },
			[19] = { name = "nasi", price = 500, amount = 50, info = {}, type = "item", slot = 19, },
			[20] = { name = "santan", price = 500, amount = 50, info = {}, type = "item", slot = 20, },
			[21] = { name = "kacang", price = 500, amount = 50, info = {}, type = "item", slot = 21, },
        }
    },
    Emotes = {
        burger = {prop = `prop_cs_burger_01`, bone = 18905, anim = 'mp_player_int_eat_burger', dict = 'mp_player_inteat@burger', coords = vec3(0.130000, 0.050000, 0.020000), rot = vec3(-50.000000, 16.000000, 60.000000)},
        bbqf = {prop = `prop_fish_slice_01`, bone = 28422, anim = 'idle_b', dict = 'amb@prop_human_bbq@male@idle_a', coords = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0)},
        fries = {prop = `prop_food_bs_chips`, bone = 18905, anim = 'mp_player_int_eat_burger_fp', dict = 'mp_player_inteat@burger', coords = vec3(0.090000, -0.060000, 0.050000), rot = vec3(300.000000, 150.000000, 0.000000)},
        bsdrink = {prop = `prop_food_bs_juice02`, bone = 28422, anim = 'idle_c', dict = 'amb@world_human_drinking@coffee@male@idle_a', coords = vec3(0.02, 0.0, -0.10), rot = vec3(0.0, 0.0, -0.50)},
    }
}