fx_version 'cerulean'
game 'gta5'

author 'Bear White'
description 'AbangCafe Job'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts {
    'bridge/client/**.lua',
    'cl_abangcafe.lua',
}

server_scripts {
    'bridge/server/**.lua',
    'sv_abangcafe.lua',
}

lua54 'yes'