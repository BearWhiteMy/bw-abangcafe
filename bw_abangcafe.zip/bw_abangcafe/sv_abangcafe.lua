local Config = lib.require('config')
local AbangcafeFood = {
    ---Zone Makanan
    ['meegoreng'] = {
        event = 'bw_abangcafe:client:makeFood',
        remove = { {ing = 'mee', amount = 1}, {ing = 'minyak', amount = 1}, {ing = 'telur', amount = 1}, {ing = 'pingan', amount = 1}, {ing = 'daunpisang', amount = 1}, }
    },
    ['nasilemak'] = {
        event = 'bw_abangcafe:client:makeFood',
        remove = { {ing = 'nasi', amount = 1}, {ing = 'telur', amount = 1}, {ing = 'santan', amount = 1}, {ing = 'pingan', amount = 1}, {ing = 'kacang', amount = 1}, }
    },
    ['roticanai'] = {
        event = 'bw_abangcafe:client:makeFood',
        remove = { {ing = 'tepung', amount = 1}, {ing = 'water_bottle', amount = 1}, {ing = 'planta', amount = 1}, {ing = 'pingan', amount = 1}, {ing = 'minyak', amount = 1}, }
    },
    ['meekari'] = {
        event = 'bw_abangcafe:client:makeFood',
        remove = { {ing = 'mee', amount = 1}, {ing = 'water_bottle', amount = 1}, {ing = 'kari', amount = 1}, {ing = 'telur', amount = 1}, {ing = 'mangkuk', amount = 1}, }
    },
    ['chickenchop'] = {
        event = 'bw_abangcafe:client:makeFood',
        remove = { {ing = 'ayam', amount = 1}, {ing = 'mixvege', amount = 1}, {ing = 'pingan', amount = 1}, {ing = 'coslow', amount = 1}, {ing = 'minyak', amount = 1}, }
    },
    ---Zone Air
    ['tehais'] = {
        event = 'bw_abangcafe:client:makeDrink',
        remove = { {ing = 'teh', amount = 1}, {ing = 'water_bottle', amount = 1}, {ing = 'cawan', amount = 1}, }
    },
    ['miloais'] = {
        event = 'bw_abangcafe:client:makeDrink',
        remove = { {ing = 'milo', amount = 1}, {ing = 'water_bottle', amount = 1}, {ing = 'cawan', amount = 1}, }
    },
    ['applejus'] = {
        event = 'bw_abangcafe:client:makeDrink',
        remove = { {ing = 'apple', amount = 1}, {ing = 'water_bottle', amount = 1}, {ing = 'cawan', amount = 1}, }
    },
    ['strawberryjus'] = {
        event = 'bw_abangcafe:client:makeDrink',
        remove = { {ing = 'strawberry', amount = 1}, {ing = 'water_bottle', amount = 1}, {ing = 'cawan', amount = 1}, }
    },
}

lib.callback.register('bw_abangcafe:server:handleFood', function(source, itemName)
    local src = source
    local Player = GetPlayer(src)

    local food = AbangcafeFood[itemName]
    if not food or not isAbangCafe(Player) then return end

    local canMake = true
    for _, ingredient in pairs(food.remove) do
        if not itemCount(Player, ingredient.ing, ingredient.amount) then
            canMake = false
            break
        end
    end

    if not canMake then
        return DoNotification(src, 'You don\'t have all the required ingredients.', 'error')
    end

    for _, ingredient in pairs(food.remove) do
        RemoveItem(Player, ingredient.ing, ingredient.amount)
    end
    TriggerClientEvent(food.event, src)
    SetTimeout(Config.CookDuration, function() AddItem(Player, itemName, 1) end)
end)

lib.callback.register('bw_abangcafe:server:removeConsumable', function(source, item, slot)
    local src = source
    local Player = GetPlayer(src)
    RemoveItemFromSlot(Player, item, 1, slot)
end)