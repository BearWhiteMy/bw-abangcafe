local burgerZones = {}
local Config = lib.require('config')
local ox_inv = GetResourceState('ox_inventory') == 'started'
local emoteProp

local ac_blip = AddBlipForCoord(Config.BlipCoords)
SetBlipSprite(ac_blip, 106)
SetBlipDisplay(ac_blip, 4)
SetBlipScale(ac_blip, 0.5)
SetBlipAsShortRange(ac_blip, true)
SetBlipColour(ac_blip, 75)
BeginTextCommandSetBlipName('STRING')
AddTextComponentSubstringPlayerName('Abangcafe')
EndTextCommandSetBlipName(ac_blip)

local function toggleEmotes(bool, emote)
    if bool then
        local doEmote = Config.Emotes[emote]
        lib.requestAnimDict(doEmote.dict, 2000)
        lib.requestModel(doEmote.prop, 2000)
        if doEmote.prop then
            emoteProp = CreateObject(doEmote.prop, 0.0, 0.0, 0.0, true, true, false)
            AttachEntityToEntity(emoteProp, cache.ped, GetPedBoneIndex(cache.ped, doEmote.bone), doEmote.coords.x, doEmote.coords.y, doEmote.coords.z, doEmote.rot.x, doEmote.rot.y, doEmote.rot.z, true, true, false, true, 1, true)
        end
        TaskPlayAnim(cache.ped, doEmote.dict, doEmote.anim, 8.0, 8.0, -1, 49, 0, 0, 0, 0)
        SetModelAsNoLongerNeeded(doEmote.prop)
    else
        ClearPedTasks(cache.ped)
        if emoteProp and DoesEntityExist(emoteProp) then 
            DetachEntity(emoteProp, true, false) 
            DeleteEntity(emoteProp)
            emoteProp = nil
        end
    end
end

function createJobZones()
    for k, v in pairs(Config.Zones) do
        exports['qb-target']:AddCircleZone('abangCafeZone'..k, v.coords, v.radius,{ 
            name= 'abangCafeZone'..k, 
            debugPoly = false, 
            useZ=true, 
        }, {
            options = {
                { event = v.event, icon = v.icon, label = v.label, job = v.job, },
            },
            distance = 1.5
        })
        burgerZones[#burgerZones+1] = 'abangCafeZone'..k
    end
end

function removeJobZones()
    for i = 1, #burgerZones do
        exports['qb-target']:RemoveZone(burgerZones[i])
    end
    table.wipe(burgerZones)
end
    
AddEventHandler('bw_abangcafe:client:frontTray', function()
    if ox_inv then
        exports.ox_inventory:openInventory('stash', { id = 'AC_Front_Tray_1'})
    else
        TriggerEvent('inventory:client:SetCurrentStash', 'AC_Front_Tray_1')
        TriggerServerEvent('inventory:server:OpenInventory', 'stash', 'AC_Front_Tray_1', {
            maxweight = 75000,
            slots = 10,
        })
    end
end)

AddEventHandler('bw_abangcafe:client:frontTray2', function()
    if ox_inv then
        exports.ox_inventory:openInventory('stash', { id = 'AC_Front_Tray_2'})
    else
        TriggerEvent('inventory:client:SetCurrentStash', 'AC_Front_Tray_2')
        TriggerServerEvent('inventory:server:OpenInventory', 'stash', 'AC_Front_Tray_2', {
            maxweight = 75000,
            slots = 10,
        })
    end
end)

AddEventHandler('bw_abangcafe:client:passThrough', function()
    if ox_inv then
        exports.ox_inventory:openInventory('stash', { id = 'AC_Big_Tray'})
    else
        TriggerEvent('inventory:client:SetCurrentStash', 'AC_Big_Tray')
        TriggerServerEvent('inventory:server:OpenInventory', 'stash', 'AC_Big_Tray', {
            maxweight = 150000,
            slots = 20,
        })
    end
end)

AddEventHandler('bw_abangcafe:client:ingredientStore', function()
    if ox_inv then
        exports.ox_inventory:openInventory('shop', { id = 1, type = 'Ingredients - Abangcafe'})
    else
        TriggerServerEvent('inventory:server:OpenInventory', 'shop', 'abangcafe', Config.Items)
    end
end)

RegisterNetEvent('bw_abangcafe:client:Eat', function(itemName, itemSlot, emote)
end)

RegisterNetEvent('bw_abangcafe:client:Drink', function(itemName, itemSlot, emote)
end)

RegisterNetEvent('bw_abangcafe:client:makeFood', function()
    if GetInvokingResource() then return end
    toggleEmotes(true, 'bbqf') --Boleh Tukar Emote Lain Ikut Command Emote
    if lib.progressCircle({
        duration = Config.CookDuration,
        position = 'bottom',
        label = 'Making food..',
        useWhileDead = true,
        canCancel = false,
        disable = { move = false, car = false, mouse = false, combat = true, },
    }) then
        toggleEmotes(false)
        TriggerEvent('bw_abangcafe:client:cookBurgers')
    end
end)

--[[RegisterNetEvent('bw_abangcafe:client:makeFries', function()
    if GetInvokingResource() then return end
    toggleEmotes(true, 'bbqf') --Boleh Tukar Emote Lain Ikut Command Emote
    if lib.progressCircle({
        duration = Config.CookDuration,
        position = 'bottom',
        label = 'Making some crispy fries..',
        useWhileDead = true,
        canCancel = false,
        disable = { move = false, car = false, mouse = false, combat = true, },
    }) then
        toggleEmotes(false)
        TriggerEvent('bw_abangcafe:client:friesStation')
    end
end)]]--

RegisterNetEvent('bw_abangcafe:client:makeDrink', function()
    if GetInvokingResource() then return end
    if lib.progressCircle({
        duration = Config.CookDuration,
        position = 'bottom',
        label = 'Making Drinks..',
        useWhileDead = true,
        canCancel = false,
        disable = { move = false, car = false, mouse = false, combat = true, },
    }) then
        TriggerEvent('bw_abangcafe:client:drinkStation')
    end
end)

AddEventHandler('bw_abangcafe:client:cookBurgers', function()
    local abangCafe = 'ac_info'
    local acMenu = {
        id = abangCafe,
        title = 'Burger Station',
        options = {
            {
                title = 'Mee Goreng Mamak',
                description = 'Requires: 1x Mee Kuning | 1x Minyak Masak | 1x Telur Ayam | 1x Pingan | 1x Daun Pisang',
                icon = 'fa-solid fa-burger',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'meegoreng')
                end,
            },
            {
                title = 'Nasi Lemak Abang',
                description = 'Requires: 1x Nasi Lemak | 1x Telur Ayam | 1x Santan Kotak | 1x Pingan | 1x Kacang Goreng',
                icon = 'fa-solid fa-burger',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'nasilemak')
                end,
            },
            {
                title = 'Roti Canai Kosong',
                description = 'Requires: 1x Tepung Gandum | 1x Air Mineral | 1x Planta | 1x Pingan | 1x Minyak Masak',
                icon = 'fa-solid fa-burger',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'roticanai')
                end,
            },
            {
                title = 'Mee Kari Padu',
                description = 'Requires: 1x Mee Kuning | 1x Air Mineral | 1x Serbuk Kari | 1x Telur Ayam | 1x Mangkuk',
                icon = 'fa-solid fa-burger',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'meekari')
                end,
            },
            {
                title = 'Chicken Chop Abang',
                description = 'Requires: 1x Isi Ayam | 1x Sayur Campur | 1x Pingan | 1x Coslow | 1x Minyak Masak',
                icon = 'fa-solid fa-burger',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'chickenchop')
                end,
            },
        }
    }
    lib.registerContext(acMenu)
    lib.showContext(abangCafe)
end)

AddEventHandler('bw_abangcafe:client:drinkStation', function()
    local abangCafe = 'ac_info'
    local acMenu = {
        id = abangCafe,
        title = 'Drink Station',
        options = {
            {
                title = 'Teh Ais Cameron',
                description = 'Requires: 1x Serbuk Teh | 1x Air Mineral | 1x Cawan',
                icon = 'fa-solid fa-mug-hot',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'tehais')
                end,
            },
            {
                title = 'Milo Ais Dinasor',
                description = 'Requires: 1x Serbuk Milo | 1x Air Mineral | 1x Cawan',
                icon = 'fa-solid fa-mug-hot',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'miloais')
                end,
            },
            {
                title = 'Apple Jus Abang',
                description = 'Requires: 1x Buah Apple | 1x Air Mineral | 1x Cawan',
                icon = 'fa-solid fa-mug-hot',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'applejus')
                end,
            },
            {
                title = 'Strawberry Jus Abang',
                description = 'Requires: 1x Buah Strawberry | 1x Air Mineral | 1x Cawan',
                icon = 'fa-solid fa-mug-hot',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'strawberryjus')
                end,
            },
        }
    }
    lib.registerContext(acMenu)
    lib.showContext(abangCafe)
end)
---TAK GUNA LAGI
--[[AddEventHandler('bw_abangcafe:client:friesStation', function()
    local abangCafe = 'ac_info'
    local acMenu = {
        id = abangCafe,
        title = 'Fries Station',
        options = {
            {
                title = 'Fries',
                description = 'Requires: 2x Potato',
                icon = 'fa-solid fa-fire-burner',
                onSelect = function()
                    lib.callback.await('bw_abangcafe:server:handleFood', false, 'burger-fries')
                end,
            },
        }
    }
    lib.registerContext(acMenu)
    lib.showContext(abangCafe)
end)]]--

AddEventHandler('onResourceStop', function(resourceName) 
    if GetCurrentResourceName() == resourceName then
        removeJobZones()
    end 
end)